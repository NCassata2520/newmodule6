﻿namespace Class_5.Services;

public interface IMainService
{
    void Invoke();
}
