﻿using System;

namespace AbstractExample.Models
{
    public class Video : Media
    {
        public int ID { get; set; }
        public string Title { get; set; }

        public string Format { get; set; }
        public int Length { get; set; }
        public int[] Regions { get; set; }

        public override string Display()
        {
            throw new NotImplementedException();
        }
    }
}
